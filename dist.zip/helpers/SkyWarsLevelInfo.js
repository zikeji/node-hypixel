"use strict";
/**
 * This portion of code was ported from the [hypixel-php](https://github.com/Plancke/hypixel-php) library.
 *
 * Copyright (c) 2021 Zikeji
 * Copyright (c) 2017 Aäron Plancke
 *
 * For the original full copyright and license information, please view the LICENSE-HYPIXEL-PHP.md that was distributed with this source code.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSkyWarsLevelInfo = exports.totalExpToSkyWarsLevel = void 0;
const SkyWarsPrestige_1 = require("./SkyWarsPrestige");
/** @internal */
const skyWarsLevelConstants = {
    expPerLevel: 10000,
    easyLevelExp: [0, 20, 50, 80, 100, 250, 500, 1000, 1500, 2500, 4000, 5000],
};
/**
 * Returns the total amount of exp it takes to get to a certain level.
 * @param level The level of the player.
 */
function totalExpToSkyWarsLevel(level) {
    let acc = 0;
    const easyLevelCount = Math.min(level, skyWarsLevelConstants.easyLevelExp.length);
    for (let i = 0; i < easyLevelCount; i += 1) {
        acc += skyWarsLevelConstants.easyLevelExp[i];
    }
    return level <= skyWarsLevelConstants.easyLevelExp.length
        ? acc
        : acc +
            (level - skyWarsLevelConstants.easyLevelExp.length) *
                skyWarsLevelConstants.expPerLevel;
}
exports.totalExpToSkyWarsLevel = totalExpToSkyWarsLevel;
function getSkyWarsLevelInfo(data, includePrestige) {
    var _a;
    const currentExp = typeof data === "number"
        ? data
        : (_a = data.stats.SkyWars) === null || _a === void 0 ? void 0 : _a.skywars_experience;
    if (typeof currentExp !== "number" || Number.isNaN(currentExp)) {
        throw new TypeError("Data supplied does not contain player SkyWars experience.");
    }
    let expAcc = 0;
    let level = -1;
    for (let i = 0; i < skyWarsLevelConstants.easyLevelExp.length; i += 1) {
        const expPerLevel = skyWarsLevelConstants.easyLevelExp[i];
        expAcc += expPerLevel;
        if (currentExp < expAcc) {
            level = i;
            expAcc -= expPerLevel;
            break;
        }
    }
    if (level === -1) {
        level =
            skyWarsLevelConstants.easyLevelExp.length +
                Math.floor((currentExp - expAcc) / skyWarsLevelConstants.expPerLevel);
        expAcc +=
            (level - skyWarsLevelConstants.easyLevelExp.length) *
                skyWarsLevelConstants.expPerLevel;
    }
    const expToLevel = expAcc;
    const nextLevelExp = expToLevel +
        (level < skyWarsLevelConstants.easyLevelExp.length
            ? skyWarsLevelConstants.easyLevelExp[level]
            : skyWarsLevelConstants.expPerLevel);
    const expToNextLevel = nextLevelExp - expToLevel;
    const expInCurrentLevel = currentExp - expToLevel;
    const remainingExpToNextLevel = nextLevelExp - currentExp;
    const nextLevelProgress = expInCurrentLevel / expToNextLevel;
    const preciseLevel = level + nextLevelProgress;
    const info = {
        level,
        preciseLevel,
        currentExp,
        expToLevel,
        expToNextLevel,
        remainingExpToNextLevel,
    };
    if (includePrestige !== true) {
        return info;
    }
    info.prestige = SkyWarsPrestige_1.getSkyWarsPrestigeForLevel(level);
    info.expToPrestige = totalExpToSkyWarsLevel(info.prestige.minimumLevel);
    const prestigeIndex = SkyWarsPrestige_1.SkyWarsPrestiges.indexOf(info.prestige);
    if (prestigeIndex + 1 === SkyWarsPrestige_1.SkyWarsPrestiges.length) {
        return info;
    }
    info.nextPrestige = SkyWarsPrestige_1.SkyWarsPrestiges[prestigeIndex + 1];
    info.expToNextPrestige = totalExpToSkyWarsLevel(info.nextPrestige.minimumLevel);
    info.remainingExpToNextPrestige = info.expToNextPrestige - info.currentExp;
    info.progressToNextPrestige = info.currentExp / info.expToNextPrestige;
    return info;
}
exports.getSkyWarsLevelInfo = getSkyWarsLevelInfo;
//# sourceMappingURL=SkyWarsLevelInfo.js.map