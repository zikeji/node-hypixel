import { Components } from "../types/api";
/**
 * Interface that describes a collection category, e.g. "Farming"
 */
export interface SkyBlockProfileCollectionGroup {
    /** The ID of the group, e.g. "FARMING" */
    id: string;
    /** The name of the group, e.g. "Farming" */
    name: string;
    /**
     * A number representing the percentage progress the profile is through this group, e.g. "100" or "83.33333333333334"
     * @example
     * ```typescript
     * const progress = collections[0].progress;
     * console.log(progress);
     * // output:
     * 83.33333333333334
     *
     * const percent = Math.round(progress * 100) / 100;
     * console.log(percent);
     * // output:
     * 83.33
     * ```
     */
    progress: number;
    /** Collection children that the profile has reached the maximum tier of. */
    maxedChildCollections: number;
    /** How many collections are in this collection group. */
    totalCollections: number;
    /** The children of this collection group. */
    children: SkyBlockProfileCollection[];
}
/**
 * Interface describing an individual collection.
 */
export interface SkyBlockProfileCollection {
    /** The ID of this collection, e.g. "LOG:2" */
    id: string;
    /** The name of this collection, e.g. "Birch Wood" */
    name: string;
    /** The tier the profile has reached. */
    tier: number;
    /** The next tier the profile can reach. If the profile has reached the max tier, this value is omitted. */
    nextTier?: number;
    /** The maximum tier of this collection. */
    maxTier: number;
    /**
     * The amount of resources in this collection the profile has collected toward tiers.
     *
     * **Note:**
     * If the profile is a coop and all players do not have their collection API enabled, this will only account for the amounts collected by members with their collection API enabled.
     */
    amount: number;
    /** The amount required to reach the next collection tier. If the profile has reached the max tier, this value is omitted. */
    nextTierAmountRequired?: number;
    /** The progress the profile is toward maxing this collection. */
    progress: number;
}
export declare type SkyBlockProfileCollections = SkyBlockProfileCollectionGroup[];
/**
 * This helper takes a profile and scans all of it's member's to get the most accurate collection information possible. Returns false is none of the members of the profile had their collections API enabled.
 * @param profile The SkyBlock profile object you want to check.
 * @param collections The collections resource object.
 * @category Helper
 */
export declare function getSkyBlockProfileMemberCollections(profile: Pick<NonNullable<Components.Schemas.SkyBlockProfile>, "members">, collections: Components.Schemas.SkyBlockResourcesParentCollections): SkyBlockProfileCollections | false;
