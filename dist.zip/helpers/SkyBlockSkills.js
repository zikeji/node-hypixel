"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSkyBlockProfileMemberSkills = void 0;
/**
 * This helper takes a profile member and converts raw skill EXP to skill levels using the skills resources. Returns false is none of the profile member does not have their skills API enabled.
 * @param profileMember The SkyBlock profile member object you want to check.
 * @param skills The skills resource object.
 * @category Helper
 */
function getSkyBlockProfileMemberSkills(profileMember, skills) {
    let hasApi = false;
    const result = {};
    for (let i = 0; i < Object.keys(skills).length; i += 1) {
        const skillName = Object.keys(skills)[i];
        const skill = skills[skillName];
        const skillKey = `experience_skill_${skillName.toLowerCase()}`;
        let exp = 0;
        if (skillKey in profileMember) {
            exp = profileMember[skillKey];
            hasApi = true;
        }
        let level = 0;
        let totalExpToLevel = 0;
        let expToNextLevel = 0;
        for (let ii = 0; ii < skill.levels.length; ii += 1) {
            const levelInfo = skill.levels[ii];
            if (levelInfo.totalExpRequired > exp) {
                expToNextLevel = levelInfo.totalExpRequired - exp;
                break;
            }
            level = levelInfo.level;
            totalExpToLevel = levelInfo.totalExpRequired;
        }
        result[skillName] = {
            name: skill.name,
            description: skill.description,
            level,
            exp,
            totalExpToLevel,
            expToNextLevel,
            maxLevel: skill.maxLevel,
        };
    }
    if (hasApi === false) {
        return false;
    }
    return result;
}
exports.getSkyBlockProfileMemberSkills = getSkyBlockProfileMemberSkills;
//# sourceMappingURL=SkyBlockSkills.js.map