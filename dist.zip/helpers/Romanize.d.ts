/**
 * Quick helper function that will help you convert a number to a roman numeral for display purposes.
 * @param value The number you want to convert to a roman numeral.
 * @category Helper
 */
export declare function romanize(value: number): string;
