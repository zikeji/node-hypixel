"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeMinecraftFormatting = exports.MinecraftColorAsHex = exports.MinecraftFormatting = void 0;
/**
 * An enum describing color names and their Minecraft format variants.
 */
var MinecraftFormatting;
(function (MinecraftFormatting) {
    MinecraftFormatting["BLACK"] = "\u00A70";
    MinecraftFormatting["DARK_BLUE"] = "\u00A71";
    MinecraftFormatting["DARK_GREEN"] = "\u00A72";
    MinecraftFormatting["DARK_AQUA"] = "\u00A73";
    MinecraftFormatting["DARK_RED"] = "\u00A74";
    MinecraftFormatting["DARK_PURPLE"] = "\u00A75";
    MinecraftFormatting["GOLD"] = "\u00A76";
    MinecraftFormatting["GRAY"] = "\u00A77";
    MinecraftFormatting["DARK_GRAY"] = "\u00A78";
    MinecraftFormatting["BLUE"] = "\u00A79";
    MinecraftFormatting["GREEN"] = "\u00A7a";
    MinecraftFormatting["AQUA"] = "\u00A7b";
    MinecraftFormatting["RED"] = "\u00A7c";
    MinecraftFormatting["LIGHT_PURPLE"] = "\u00A7d";
    MinecraftFormatting["YELLOW"] = "\u00A7e";
    MinecraftFormatting["WHITE"] = "\u00A7f";
    MinecraftFormatting["BOLD"] = "\u00A7l";
    MinecraftFormatting["STRIKETHROUGH"] = "\u00A7m";
    MinecraftFormatting["UNDERLINE"] = "\u00A7n";
    MinecraftFormatting["ITALIC"] = "\u00A7o";
    MinecraftFormatting["RESET"] = "\u00A7r";
    MinecraftFormatting["MAGIC"] = "\u00A7k";
})(MinecraftFormatting = exports.MinecraftFormatting || (exports.MinecraftFormatting = {}));
/**
 * An enum that'll let you you get a hex color code for a specific Minecraft color formatting sequence.
 */
var MinecraftColorAsHex;
(function (MinecraftColorAsHex) {
    MinecraftColorAsHex["\u00A70"] = "000000";
    MinecraftColorAsHex["\u00A71"] = "0000AA";
    MinecraftColorAsHex["\u00A72"] = "00AA00";
    MinecraftColorAsHex["\u00A73"] = "00AAAA";
    MinecraftColorAsHex["\u00A74"] = "AA0000";
    MinecraftColorAsHex["\u00A75"] = "AA00AA";
    MinecraftColorAsHex["\u00A76"] = "FFAA00";
    MinecraftColorAsHex["\u00A77"] = "AAAAAA";
    MinecraftColorAsHex["\u00A78"] = "555555";
    MinecraftColorAsHex["\u00A79"] = "5555FF";
    MinecraftColorAsHex["\u00A7a"] = "55FF55";
    MinecraftColorAsHex["\u00A7b"] = "55FFFF";
    MinecraftColorAsHex["\u00A7c"] = "FF5555";
    MinecraftColorAsHex["\u00A7d"] = "FF55FF";
    MinecraftColorAsHex["\u00A7e"] = "FFFF55";
    MinecraftColorAsHex["\u00A7f"] = "FFFFFF";
})(MinecraftColorAsHex = exports.MinecraftColorAsHex || (exports.MinecraftColorAsHex = {}));
/** @internal */
const REMOVE_FORMATTING_REGEX = /§[0-9a-flmnokr]/gi;
/**
 * This helper will take a string and remove any of Minecraft's formatting sequence. Useful when parsing item lore or similar elements.
 * @param value Any string with minecraft formatting.
 * @category Helper
 */
function removeMinecraftFormatting(value) {
    return value.replace(REMOVE_FORMATTING_REGEX, "");
}
exports.removeMinecraftFormatting = removeMinecraftFormatting;
//# sourceMappingURL=MinecraftFormatting.js.map