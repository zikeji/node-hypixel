"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformItemData = void 0;
const NBT_1 = require("../util/NBT");
/**
 * This helper will transform NBT data into a typed object using prismarine-nbt. It will also transform any backpacks/bags with item data so you can explore those as well.
 * @param value A Base64 item data string, NBT byte array, or buffer. If Deno, no Buffer but a Uint8Array is supported.
 * @category Helper
 */
function transformItemData(value) {
    return __awaiter(this, void 0, void 0, function* () {
        const data = yield NBT_1.parse(value);
        return Promise.all(data.map((item) => __awaiter(this, void 0, void 0, function* () {
            if (Object.entries(item).length === 0) {
                return null;
            }
            /* istanbul ignore else */
            if (item.tag) {
                if (item.tag.SkullOwner) {
                    const skullOwner = item.tag.SkullOwner;
                    const propertiesData = skullOwner.Properties.textures.shift();
                    /* istanbul ignore else */
                    if (propertiesData) {
                        item.tag.SkullOwner.Properties = JSON.parse(Buffer.from(propertiesData.Value, "base64").toString());
                        /* istanbul ignore if */
                        if (skullOwner.Properties.textures.length > 0) {
                            item.tag.SkullOwner.ExtraProperties = skullOwner.Properties.textures.map(({ Value }) => JSON.parse(Buffer.from(Value, "base64").toString()));
                        }
                    }
                    else {
                        item.tag.SkullOwner.Properties = null;
                    }
                }
                if (item.tag.ExtraAttributes) {
                    const extraAttributes = item.tag
                        .ExtraAttributes;
                    yield Promise.all(Object.keys(extraAttributes).map((key) => __awaiter(this, void 0, void 0, function* () {
                        /* istanbul ignore if */
                        if (key.endsWith("_backpack_data") ||
                            key.endsWith("_bag_data")) {
                            extraAttributes[key] = yield transformItemData(extraAttributes[key]);
                        }
                    })));
                }
            }
            return item;
        })));
    });
}
exports.transformItemData = transformItemData;
//# sourceMappingURL=TransformItemData.js.map