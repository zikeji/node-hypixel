import { Components } from "../types/api";
import { NBTInventory } from "./TransformItemData";
/**
 * Interface used in the {@link SkyBlockProfileMemberWithTransformedInventories} intersection to describe the intellisense for the inventory after being transformed.
 */
export interface SkyBlockProfileTransformedInventories {
    inv_armor: NBTInventory;
    candy_inventory_contents?: NBTInventory;
    ender_chest_contents?: NBTInventory;
    fishing_bag?: NBTInventory;
    inv_contents?: NBTInventory;
    potion_bag?: NBTInventory;
    quiver?: NBTInventory;
    talisman_bag?: NBTInventory;
    wardrobe_contents?: NBTInventory;
}
/**
 * This type is a intersection type omitting the default inventory types and including the transformed inventory types.
 */
export declare type SkyBlockProfileMemberWithTransformedInventories = Omit<Components.Schemas.SkyBlockProfileMember, keyof SkyBlockProfileTransformedInventories> & SkyBlockProfileTransformedInventories;
/**
 * This helper will loop over all the possible inventories on a profile and run the {@link transformSkyBlockItemData} helper on them, returning the member object with the transformed properties.
 * @param member The profile member object that you want to transform the inventory data of.
 * @category Helper
 */
export declare function transformSkyBlockProfileMemberInventories(member: Components.Schemas.SkyBlockProfileMember): Promise<SkyBlockProfileMemberWithTransformedInventories>;
