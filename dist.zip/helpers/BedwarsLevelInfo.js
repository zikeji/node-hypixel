"use strict";
/**
 * This portion of code was ported from the [hypixel-php](https://github.com/Plancke/hypixel-php) library.
 *
 * Copyright (c) 2020 Zikeji
 * Copyright (c) 2017 Aäron Plancke
 *
 * For the original full copyright and license information, please view the LICENSE-HYPIXEL-PHP.md that was distributed with this source code.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBedwarsLevelInfo = void 0;
const MinecraftFormatting_1 = require("./MinecraftFormatting");
/** @internal */
var BEDWARS_LEVEL_CONSTANTS;
(function (BEDWARS_LEVEL_CONSTANTS) {
    BEDWARS_LEVEL_CONSTANTS[BEDWARS_LEVEL_CONSTANTS["EL"] = 4] = "EL";
    BEDWARS_LEVEL_CONSTANTS[BEDWARS_LEVEL_CONSTANTS["XPP"] = 487000] = "XPP";
    BEDWARS_LEVEL_CONSTANTS[BEDWARS_LEVEL_CONSTANTS["LPP"] = 100] = "LPP";
    BEDWARS_LEVEL_CONSTANTS[BEDWARS_LEVEL_CONSTANTS["HP"] = 10] = "HP";
})(BEDWARS_LEVEL_CONSTANTS || (BEDWARS_LEVEL_CONSTANTS = {}));
/**
 * Calculates the BedWars prestige and level of a player and returns a {@link BedwarsLevelInfo} interface.
 * @category Helper
 */
function getBedwarsLevelInfo(data) {
    var _a, _b, _c;
    const currentExp = typeof data === "number"
        ? data
        : (_b = (_a = data.stats.Bedwars) === null || _a === void 0 ? void 0 : _a.Experience) !== null && _b !== void 0 ? _b : (_c = data.stats.Bedwars) === null || _c === void 0 ? void 0 : _c.Experience_new;
    if (typeof currentExp !== "number" || Number.isNaN(currentExp)) {
        throw new TypeError("Data supplied does not contain player Bedwars experience.");
    }
    const prestiges = Math.floor(currentExp / BEDWARS_LEVEL_CONSTANTS.XPP);
    let level = prestiges * BEDWARS_LEVEL_CONSTANTS.LPP;
    let expWithoutPrestiges = currentExp - prestiges * BEDWARS_LEVEL_CONSTANTS.XPP;
    for (let i = 1; i <= BEDWARS_LEVEL_CONSTANTS.EL; i += 1) {
        let elExp = 500;
        const rL = i % BEDWARS_LEVEL_CONSTANTS.LPP;
        for (let ii = 0; ii < rL; ii += 1) {
            elExp += ii * 500;
        }
        if (expWithoutPrestiges < elExp) {
            break;
        }
        level += 1;
        expWithoutPrestiges -= elExp;
    }
    level += Math.floor(expWithoutPrestiges / 5000);
    let prestige = Math.floor(level / BEDWARS_LEVEL_CONSTANTS.LPP);
    if (prestige > BEDWARS_LEVEL_CONSTANTS.HP) {
        prestige = BEDWARS_LEVEL_CONSTANTS.HP;
    }
    let prestigeName = "None";
    let prestigeColor = MinecraftFormatting_1.MinecraftFormatting.GRAY;
    switch (prestige) {
        case 1:
            prestigeName = "Iron";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.WHITE;
            break;
        case 2:
            prestigeName = "Gold";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.GOLD;
            break;
        case 3:
            prestigeName = "Diamond";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.AQUA;
            break;
        case 4:
            prestigeName = "Emerald";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.DARK_GREEN;
            break;
        case 5:
            prestigeName = "Sapphire";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.DARK_AQUA;
            break;
        case 6:
            prestigeName = "Ruby";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.DARK_RED;
            break;
        case 7:
            prestigeName = "Crystal";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.LIGHT_PURPLE;
            break;
        case 8:
            prestigeName = "Opal";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.BLUE;
            break;
        case 9:
            prestigeName = "Amethyst";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.DARK_PURPLE;
            break;
        case 10:
            prestigeName = "Rainbow";
            prestigeColor = MinecraftFormatting_1.MinecraftFormatting.WHITE;
            break;
        default:
        // noop
    }
    const levelInCurrentPrestige = level - prestige * BEDWARS_LEVEL_CONSTANTS.LPP;
    return {
        level,
        prestige,
        prestigeName,
        prestigeColor,
        prestigeColorHex: MinecraftFormatting_1.MinecraftColorAsHex[prestigeColor],
        levelInCurrentPrestige,
    };
}
exports.getBedwarsLevelInfo = getBedwarsLevelInfo;
//# sourceMappingURL=BedwarsLevelInfo.js.map