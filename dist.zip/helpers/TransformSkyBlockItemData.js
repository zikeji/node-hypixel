"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformSkyBlockProfileMemberInventories = void 0;
const TransformItemData_1 = require("./TransformItemData");
/** @internal */
const SKYBLOCK_INVENTORIES = [
    "inv_armor",
    "candy_inventory_contents",
    "ender_chest_contents",
    "fishing_bag",
    "inv_contents",
    "potion_bag",
    "quiver",
    "talisman_bag",
    "wardrobe_contents",
];
/**
 * This helper will loop over all the possible inventories on a profile and run the {@link transformSkyBlockItemData} helper on them, returning the member object with the transformed properties.
 * @param member The profile member object that you want to transform the inventory data of.
 * @category Helper
 */
function transformSkyBlockProfileMemberInventories(member) {
    return __awaiter(this, void 0, void 0, function* () {
        const transformedMember = member;
        yield Promise.all(SKYBLOCK_INVENTORIES.map((key) => __awaiter(this, void 0, void 0, function* () {
            const inventoryData = transformedMember[key];
            if (inventoryData && inventoryData.data) {
                try {
                    transformedMember[key] = yield TransformItemData_1.transformItemData(inventoryData.data);
                }
                catch (e) {
                    /* istanbul ignore next */
                    delete transformedMember[key];
                }
            }
        })));
        return transformedMember;
    });
}
exports.transformSkyBlockProfileMemberInventories = transformSkyBlockProfileMemberInventories;
//# sourceMappingURL=TransformSkyBlockItemData.js.map