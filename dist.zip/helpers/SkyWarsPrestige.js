"use strict";
/**
 * This portion of code was ported from the [hypixel-php](https://github.com/Plancke/hypixel-php) library.
 *
 * Copyright (c) 2021 Zikeji
 * Copyright (c) 2017 Aäron Plancke
 *
 * For the original full copyright and license information, please view the LICENSE-HYPIXEL-PHP.md that was distributed with this source code.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSkyWarsPrestigeForLevel = exports.SkyWarsPrestiges = void 0;
const MinecraftFormatting_1 = require("./MinecraftFormatting");
/**
 * An array of the prestiges in SkyWars, listed in order of lowest to highest.
 */
exports.SkyWarsPrestiges = [
    {
        id: "NONE",
        name: "None",
        color: MinecraftFormatting_1.MinecraftFormatting.GRAY,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.GRAY],
        minimumLevel: 1,
        icon: {
            version: 1,
            material: "COAL",
            typeId: 263,
            data: 0,
        },
        textIcon: null,
    },
    {
        id: "IRON",
        name: "Iron",
        color: MinecraftFormatting_1.MinecraftFormatting.WHITE,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.WHITE],
        minimumLevel: 5,
        icon: {
            version: 1,
            material: "IRON_INGOT",
            typeId: 265,
            data: 0,
        },
        textIcon: "✙",
    },
    {
        id: "GOLD",
        name: "Gold",
        color: MinecraftFormatting_1.MinecraftFormatting.GOLD,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.GOLD],
        minimumLevel: 10,
        icon: {
            version: 1,
            material: "GOLD_INGOT",
            typeId: 266,
            data: 0,
        },
        textIcon: "❤",
    },
    {
        id: "DIAMOND",
        name: "Diamond",
        color: MinecraftFormatting_1.MinecraftFormatting.AQUA,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.AQUA],
        minimumLevel: 15,
        icon: {
            version: 1,
            material: "DIAMOND",
            typeId: 264,
            data: 0,
        },
        textIcon: "☠",
    },
    {
        id: "EMERALD",
        name: "Emerald",
        color: MinecraftFormatting_1.MinecraftFormatting.DARK_GREEN,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.DARK_GREEN],
        minimumLevel: 20,
        icon: {
            version: 1,
            material: "EMERALD",
            typeId: 388,
            data: 0,
        },
        textIcon: "✦",
    },
    {
        id: "SAPPHIRE",
        name: "Sapphire",
        color: MinecraftFormatting_1.MinecraftFormatting.DARK_AQUA,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.DARK_AQUA],
        minimumLevel: 25,
        icon: {
            version: 1,
            material: "SKULL_ITEM",
            typeId: 397,
            data: 3,
        },
        textIcon: "✌",
    },
    {
        id: "RUBY",
        name: "Ruby",
        color: MinecraftFormatting_1.MinecraftFormatting.DARK_RED,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.DARK_RED],
        minimumLevel: 30,
        icon: {
            version: 1,
            material: "SKULL_ITEM",
            typeId: 397,
            data: 3,
        },
        textIcon: "❦",
    },
    {
        id: "CRYSTAL",
        name: "Crystal",
        color: MinecraftFormatting_1.MinecraftFormatting.LIGHT_PURPLE,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.LIGHT_PURPLE],
        minimumLevel: 35,
        icon: {
            version: 1,
            material: "QUARTZ",
            typeId: 406,
            data: 0,
        },
        textIcon: "✵",
    },
    {
        id: "OPAL",
        name: "Opal",
        color: MinecraftFormatting_1.MinecraftFormatting.BLUE,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.BLUE],
        minimumLevel: 40,
        icon: {
            version: 1,
            material: "SKULL_ITEM",
            typeId: 397,
            data: 3,
        },
        textIcon: "❣",
    },
    {
        id: "AMETHYST",
        name: "Amethyst",
        color: MinecraftFormatting_1.MinecraftFormatting.DARK_PURPLE,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.DARK_PURPLE],
        minimumLevel: 45,
        icon: {
            version: 1,
            material: "SKULL_ITEM",
            typeId: 397,
            data: 3,
        },
        textIcon: "☯",
    },
    {
        id: "RAINBOW",
        name: "Rainbow",
        color: MinecraftFormatting_1.MinecraftFormatting.WHITE,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.WHITE],
        minimumLevel: 50,
        icon: {
            version: 1,
            material: "SKULL_ITEM",
            typeId: 397,
            data: 3,
        },
        textIcon: "✺",
    },
    {
        id: "MYTHIC",
        name: "Mythic",
        color: MinecraftFormatting_1.MinecraftFormatting.WHITE,
        colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.WHITE],
        minimumLevel: 60,
        icon: {
            version: 1,
            material: "SKULL_ITEM",
            typeId: 397,
            data: 1,
        },
        textIcon: "ಠ_ಠ",
    },
];
/**
 * Returns a {@link SkyWarsPrestige} object for the level you supplied.
 * @param level The level of the player you are checking. TODO: obtain
 */
function getSkyWarsPrestigeForLevel(level) {
    if (typeof level !== "number" || level < 1) {
        throw new TypeError("Not a valid level.");
    }
    return exports.SkyWarsPrestiges.reduceRight((acc, prestige) => acc.id === "NONE" && level >= prestige.minimumLevel ? prestige : acc, exports.SkyWarsPrestiges[0]);
}
exports.getSkyWarsPrestigeForLevel = getSkyWarsPrestigeForLevel;
//# sourceMappingURL=SkyWarsPrestige.js.map