/**
 * An enum describing color names and their Minecraft format variants.
 */
export declare enum MinecraftFormatting {
    BLACK = "\u00A70",
    DARK_BLUE = "\u00A71",
    DARK_GREEN = "\u00A72",
    DARK_AQUA = "\u00A73",
    DARK_RED = "\u00A74",
    DARK_PURPLE = "\u00A75",
    GOLD = "\u00A76",
    GRAY = "\u00A77",
    DARK_GRAY = "\u00A78",
    BLUE = "\u00A79",
    GREEN = "\u00A7a",
    AQUA = "\u00A7b",
    RED = "\u00A7c",
    LIGHT_PURPLE = "\u00A7d",
    YELLOW = "\u00A7e",
    WHITE = "\u00A7f",
    BOLD = "\u00A7l",
    STRIKETHROUGH = "\u00A7m",
    UNDERLINE = "\u00A7n",
    ITALIC = "\u00A7o",
    RESET = "\u00A7r",
    MAGIC = "\u00A7k"
}
/**
 * An enum that'll let you you get a hex color code for a specific Minecraft color formatting sequence.
 */
export declare enum MinecraftColorAsHex {
    "§0" = "000000",
    "§1" = "0000AA",
    "§2" = "00AA00",
    "§3" = "00AAAA",
    "§4" = "AA0000",
    "§5" = "AA00AA",
    "§6" = "FFAA00",
    "§7" = "AAAAAA",
    "§8" = "555555",
    "§9" = "5555FF",
    "§a" = "55FF55",
    "§b" = "55FFFF",
    "§c" = "FF5555",
    "§d" = "FF55FF",
    "§e" = "FFFF55",
    "§f" = "FFFFFF"
}
/**
 * This helper will take a string and remove any of Minecraft's formatting sequence. Useful when parsing item lore or similar elements.
 * @param value Any string with minecraft formatting.
 * @category Helper
 */
export declare function removeMinecraftFormatting(value: string): string;
