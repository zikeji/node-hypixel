"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.romanize = void 0;
/** @hidden */
var ROMAN_NUMERALS;
(function (ROMAN_NUMERALS) {
    ROMAN_NUMERALS[ROMAN_NUMERALS["M"] = 1000] = "M";
    ROMAN_NUMERALS[ROMAN_NUMERALS["CM"] = 900] = "CM";
    ROMAN_NUMERALS[ROMAN_NUMERALS["D"] = 500] = "D";
    ROMAN_NUMERALS[ROMAN_NUMERALS["CD"] = 400] = "CD";
    ROMAN_NUMERALS[ROMAN_NUMERALS["C"] = 100] = "C";
    ROMAN_NUMERALS[ROMAN_NUMERALS["XC"] = 90] = "XC";
    ROMAN_NUMERALS[ROMAN_NUMERALS["L"] = 50] = "L";
    ROMAN_NUMERALS[ROMAN_NUMERALS["XL"] = 40] = "XL";
    ROMAN_NUMERALS[ROMAN_NUMERALS["X"] = 10] = "X";
    ROMAN_NUMERALS[ROMAN_NUMERALS["IX"] = 9] = "IX";
    ROMAN_NUMERALS[ROMAN_NUMERALS["V"] = 5] = "V";
    ROMAN_NUMERALS[ROMAN_NUMERALS["IV"] = 4] = "IV";
    ROMAN_NUMERALS[ROMAN_NUMERALS["I"] = 1] = "I";
})(ROMAN_NUMERALS || (ROMAN_NUMERALS = {}));
/**
 * Quick helper function that will help you convert a number to a roman numeral for display purposes.
 * @param value The number you want to convert to a roman numeral.
 * @category Helper
 */
function romanize(value) {
    let roman = "";
    Object.entries(ROMAN_NUMERALS).forEach(([numeral, amount]) => {
        while (value >= amount) {
            roman += numeral;
            // eslint-disable-next-line no-param-reassign
            value -= amount;
        }
    });
    return roman;
}
exports.romanize = romanize;
//# sourceMappingURL=Romanize.js.map