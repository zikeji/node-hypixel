"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSkyBlockProfileMemberCollections = void 0;
/**
 * This helper takes a profile and scans all of it's member's to get the most accurate collection information possible. Returns false is none of the members of the profile had their collections API enabled.
 * @param profile The SkyBlock profile object you want to check.
 * @param collections The collections resource object.
 * @category Helper
 */
function getSkyBlockProfileMemberCollections(profile, collections) {
    const profileCollectionValues = Object.values(profile.members).reduce((acc, member) => {
        /* istanbul ignore else */
        if (member.unlocked_coll_tiers) {
            member.unlocked_coll_tiers.forEach((uTier) => {
                acc.unlockedCollTiers.add(uTier);
            });
        }
        /* istanbul ignore else */
        if (member.collection) {
            Object.entries(member.collection).forEach(([key, quantity]) => {
                /* istanbul ignore else */
                if (!acc.collectionQuantities[key])
                    acc.collectionQuantities[key] = 0;
                acc.collectionQuantities[key] +=
                    quantity /* istanbul ignore next */ || 0;
            });
        }
        return acc;
    }, {
        unlockedCollTiers: new Set(),
        collectionQuantities: {},
    });
    if (profileCollectionValues.unlockedCollTiers.size === 0) {
        return false;
    }
    return Object.entries(collections).reduce((acc, [collectionGroupId, collectionGroup]) => {
        const group = {
            id: collectionGroupId,
            name: collectionGroup.name,
            progress: 0,
            maxedChildCollections: 0,
            totalCollections: 0,
            children: [],
        };
        Object.entries(collectionGroup.items).forEach(([collectionId, collection]) => {
            var _a, _b;
            group.totalCollections += 1;
            const child = {
                id: collectionId,
                name: collection.name,
                tier: collection.tiers.reduce((tier, tierInfo) => {
                    var _a;
                    if (profileCollectionValues.unlockedCollTiers.has(`${collectionId}_${tierInfo.tier}`) ||
                        ((_a = profileCollectionValues.collectionQuantities[collectionId]) !== null && _a !== void 0 ? _a : 0) > (tierInfo.amountRequired /* istanbul ignore next */ || 0)) {
                        // eslint-disable-next-line no-param-reassign
                        tier = tierInfo.tier;
                    }
                    return tier;
                }, 0),
                nextTier: 0,
                maxTier: collection.maxTiers,
                amount: (_a = profileCollectionValues.collectionQuantities[collectionId]) !== null && _a !== void 0 ? _a : 0,
                nextTierAmountRequired: 0,
                progress: 0,
            };
            if (child.tier === child.maxTier) {
                delete child.nextTier;
                delete child.nextTierAmountRequired;
                group.maxedChildCollections += 1;
                child.progress = 100;
            }
            else {
                child.nextTier = child.tier + 1;
                child.nextTierAmountRequired =
                    /* istanbul ignore next */
                    ((_b = collection.tiers.find((tInfo) => tInfo.tier === child.nextTier)) === null || _b === void 0 ? void 0 : _b.amountRequired /* istanbul ignore next */) || 0;
                child.progress =
                    ((profileCollectionValues.collectionQuantities[collectionId] ||
                        0) /
                        child.nextTierAmountRequired) *
                        100;
            }
            group.children.push(child);
        });
        group.progress =
            (group.maxedChildCollections / group.totalCollections) * 100;
        acc.push(group);
        return acc;
    }, []);
}
exports.getSkyBlockProfileMemberCollections = getSkyBlockProfileMemberCollections;
//# sourceMappingURL=SkyBlockCollections.js.map