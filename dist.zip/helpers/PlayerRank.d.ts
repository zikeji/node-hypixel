import { Components } from "../types/api";
import { MinecraftColorAsHex, MinecraftFormatting } from "./MinecraftFormatting";
/**
 * Describes the results from the {@link getPlayerRank} helper.
 */
export interface PlayerRank {
    /**
     * The priority of this rank as it relates to other ranks.
     */
    priority: number;
    /**
     * Name of the rank as it appears in the data.
     */
    name: string;
    /**
     * Cleaned up version of the name.
     */
    cleanName: string;
    /**
     * The chat prefix with Minecraft formatting codes.
     */
    prefix: string;
    /**
     * The chat prefix _without_ Minecraft formatting codes.
     */
    cleanPrefix: string;
    /**
     * The Minecraft formatting color code of this rank.
     */
    colorCode: MinecraftFormatting;
    /**
     * The hex value of the color code.
     */
    colorHex: MinecraftColorAsHex;
    /**
     * If they have a custom color for their rank.
     * **Note:** this can be set when the player isn't MVP++. If you want to use this value, be sure to check if the rank is SUPERSTAR (MVP++).
     */
    customRankColor?: MinecraftFormatting;
    /**
     * Same as customRankColor, but the hex version of the color.
     */
    customRankColorHex?: MinecraftColorAsHex;
    /**
     * If they have a custom color for the pluses in their rank (++).
     * **Note:** this can be set when the player isn't MVP++. If you want to use this value, be sure to check if the rank is SUPERSTAR (MVP++).
     */
    customPlusColor?: MinecraftFormatting;
    /**
     * Same as customPlusColor, but the hex version of the color.
     */
    customPlusColorHex?: MinecraftColorAsHex;
    /**
     * Whether or not this is a staff only rank.
     */
    staff: boolean;
}
/**
 * Get an {@link PlayerRank} object describing the player's rank in more detail without the need to figure out how to parse it yourself.
 * @param player The result of `client.player.uuid()`.
 * @param onlyPackages Whether to ignore their staff / youtube rank and only get their donor rank.
 * @category Helper
 */
export declare function getPlayerRank(player: NonNullable<Components.Schemas.Player>, onlyPackages?: boolean): PlayerRank;
