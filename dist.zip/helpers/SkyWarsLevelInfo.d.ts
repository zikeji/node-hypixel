/**
 * This portion of code was ported from the [hypixel-php](https://github.com/Plancke/hypixel-php) library.
 *
 * Copyright (c) 2021 Zikeji
 * Copyright (c) 2017 Aäron Plancke
 *
 * For the original full copyright and license information, please view the LICENSE-HYPIXEL-PHP.md that was distributed with this source code.
 */
import { Components } from "../types/api";
import { SkyWarsPrestige } from "./SkyWarsPrestige";
/**
 * Interface describing the results from the {@link getSkyWarsLevelInfo} function.
 */
export interface SkyWarsLevelInfo {
    level: number;
    preciseLevel: number;
    currentExp: number;
    expToLevel: number;
    expToNextLevel: number;
    remainingExpToNextLevel: number;
}
/**
 * This interface is returned by {@link getSkyWarsLevelInfo} if you passed true as the second parameter.
 */
export interface SkyWarsLevelInfoAndPrestige extends SkyWarsLevelInfo {
    prestige: SkyWarsPrestige;
    expToPrestige: number;
    nextPrestige?: SkyWarsPrestige;
    expToNextPrestige?: number;
    remainingExpToNextPrestige?: number;
    progressToNextPrestige?: number;
}
/**
 * Returns the total amount of exp it takes to get to a certain level.
 * @param level The level of the player.
 */
export declare function totalExpToSkyWarsLevel(level: number): number;
/**
 * Get SkyWars level information from a {@link Components.Schemas.Player} object or raw experience value.
 * @param data A {@link Components.Schemas.Player} object or the raw experience value.
 * @param includePrestige Whether or not to return the {@link SkyWarsPrestige} object.
 * @category Helper
 */
export declare function getSkyWarsLevelInfo(data: Components.Schemas.Player | number): SkyWarsLevelInfo;
export declare function getSkyWarsLevelInfo(data: Components.Schemas.Player | number, includePrestige: true): SkyWarsLevelInfoAndPrestige;
export declare function getSkyWarsLevelInfo(data: Components.Schemas.Player | number, includePrestige: false): SkyWarsLevelInfo;
