"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPlayerRank = exports.PlayerRanks = void 0;
const MinecraftFormatting_1 = require("./MinecraftFormatting");
/** @internal */
var PlayerRanks;
(function (PlayerRanks) {
    PlayerRanks[PlayerRanks["NON_DONOR"] = 1] = "NON_DONOR";
    PlayerRanks[PlayerRanks["VIP"] = 2] = "VIP";
    PlayerRanks[PlayerRanks["VIP_PLUS"] = 3] = "VIP_PLUS";
    PlayerRanks[PlayerRanks["MVP"] = 4] = "MVP";
    PlayerRanks[PlayerRanks["MVP_PLUS"] = 5] = "MVP_PLUS";
    PlayerRanks[PlayerRanks["SUPERSTAR"] = 6] = "SUPERSTAR";
    PlayerRanks[PlayerRanks["YOUTUBER"] = 60] = "YOUTUBER";
    PlayerRanks[PlayerRanks["JR_HELPER"] = 70] = "JR_HELPER";
    PlayerRanks[PlayerRanks["HELPER"] = 80] = "HELPER";
    PlayerRanks[PlayerRanks["MODERATOR"] = 90] = "MODERATOR";
    PlayerRanks[PlayerRanks["ADMIN"] = 100] = "ADMIN";
})(PlayerRanks = exports.PlayerRanks || (exports.PlayerRanks = {}));
/**
 * Get an {@link PlayerRank} object describing the player's rank in more detail without the need to figure out how to parse it yourself.
 * @param player The result of `client.player.uuid()`.
 * @param onlyPackages Whether to ignore their staff / youtube rank and only get their donor rank.
 * @category Helper
 */
function getPlayerRank(player, onlyPackages = false) {
    let foundRank = PlayerRanks.NON_DONOR;
    if (onlyPackages) {
        if (player.monthlyPackageRank) {
            const rank = PlayerRanks[player.monthlyPackageRank];
            if (rank) {
                foundRank = rank;
            }
        }
        if (player.newPackageRank) {
            const rank = PlayerRanks[player.newPackageRank];
            if (rank && rank > foundRank) {
                foundRank = rank;
            }
        }
        if (player.packageRank) {
            const rank = PlayerRanks[player.packageRank];
            if (rank && rank > foundRank) {
                foundRank = rank;
            }
        }
    }
    else if (typeof player.rank !== "undefined" && player.rank !== "NORMAL") {
        const rank = PlayerRanks[player.rank];
        if (rank) {
            foundRank = rank;
        }
        else {
            return getPlayerRank(player, true);
        }
    }
    else {
        return getPlayerRank(player, true);
    }
    let out;
    switch (foundRank) {
        case PlayerRanks.VIP:
            out = {
                priority: foundRank,
                name: "VIP",
                cleanName: "VIP",
                prefix: "§a[VIP]",
                cleanPrefix: "[VIP]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.GREEN,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.GREEN],
                staff: false,
            };
            break;
        case PlayerRanks.VIP_PLUS:
            out = {
                priority: foundRank,
                name: "VIP_PLUS",
                cleanName: "VIP+",
                prefix: "§a[VIP§6+§a]",
                cleanPrefix: "[VIP+]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.GREEN,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.GREEN],
                staff: false,
            };
            break;
        case PlayerRanks.MVP:
            out = {
                priority: foundRank,
                name: "MVP",
                cleanName: "MVP",
                prefix: "§b[MVP]",
                cleanPrefix: "[MVP]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.AQUA,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.AQUA],
                staff: false,
            };
            break;
        case PlayerRanks.MVP_PLUS:
            out = {
                priority: foundRank,
                name: "MVP_PLUS",
                cleanName: "MVP+",
                prefix: "§b[MVP§c+§b]",
                cleanPrefix: "[MVP+]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.AQUA,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.AQUA],
                staff: false,
            };
            break;
        case PlayerRanks.SUPERSTAR:
            out = {
                priority: foundRank,
                name: "SUPERSTAR",
                cleanName: "MVP++",
                prefix: "§6[MVP§c++§6]",
                cleanPrefix: "[MVP++]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.GOLD,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.GOLD],
                staff: false,
            };
            break;
        case PlayerRanks.YOUTUBER:
            out = {
                priority: foundRank,
                name: "YOUTUBER",
                cleanName: "YOUTUBER",
                prefix: "§c[§fYOUTUBE§c]",
                cleanPrefix: "[YOUTUBE]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.RED,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.RED],
                staff: false,
            };
            break;
        case PlayerRanks.JR_HELPER:
            out = {
                priority: foundRank,
                name: "JR_HELPER",
                cleanName: "JR HELPER",
                prefix: "§9[JR HELPER]",
                cleanPrefix: "[JR HELPER]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.BLUE,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.BLUE],
                staff: true,
            };
            break;
        case PlayerRanks.HELPER:
            out = {
                priority: foundRank,
                name: "HELPER",
                cleanName: "HELPER",
                prefix: "§9[HELPER]",
                cleanPrefix: "[HELPER]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.BLUE,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.BLUE],
                staff: true,
            };
            break;
        case PlayerRanks.MODERATOR:
            out = {
                priority: foundRank,
                name: "MODERATOR",
                cleanName: "MODERATOR",
                prefix: "§2[MOD]",
                cleanPrefix: "[MOD]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.DARK_GREEN,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.DARK_GREEN],
                staff: true,
            };
            break;
        case PlayerRanks.ADMIN:
            out = {
                priority: foundRank,
                name: "ADMIN",
                cleanName: "ADMIN",
                prefix: "§c[ADMIN]",
                cleanPrefix: "[ADMIN]",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.RED,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.RED],
                staff: true,
            };
            break;
        default:
            out = {
                priority: foundRank,
                name: "NON_DONOR",
                cleanName: "DEFAULT",
                prefix: "§7",
                cleanPrefix: "",
                colorCode: MinecraftFormatting_1.MinecraftFormatting.GRAY,
                colorHex: MinecraftFormatting_1.MinecraftColorAsHex[MinecraftFormatting_1.MinecraftFormatting.GRAY],
                staff: false,
            };
            break;
    }
    if (player.monthlyRankColor || player.rankPlusColor) {
        const customRankColor = MinecraftFormatting_1.MinecraftFormatting[player.monthlyRankColor];
        const customPlusColor = MinecraftFormatting_1.MinecraftFormatting[player.rankPlusColor];
        if (customRankColor) {
            out.customRankColor = customRankColor;
            out.customRankColorHex =
                MinecraftFormatting_1.MinecraftColorAsHex[customRankColor];
        }
        if (customPlusColor) {
            out.customPlusColor = customPlusColor;
            out.customPlusColorHex =
                MinecraftFormatting_1.MinecraftColorAsHex[customPlusColor];
        }
        if (out.priority === PlayerRanks.SUPERSTAR) {
            out.prefix = `${customRankColor !== null && customRankColor !== void 0 ? customRankColor : "§6"}[MVP${customPlusColor !== null && customPlusColor !== void 0 ? customPlusColor : "§c"}++${customRankColor !== null && customRankColor !== void 0 ? customRankColor : "§6"}]`;
        }
    }
    return out;
}
exports.getPlayerRank = getPlayerRank;
//# sourceMappingURL=PlayerRank.js.map