/**
 * This portion of code was ported from the [hypixel-php](https://github.com/Plancke/hypixel-php) library.
 *
 * Copyright (c) 2020 Zikeji
 * Copyright (c) 2017 Aäron Plancke
 *
 * For the original full copyright and license information, please view the LICENSE-HYPIXEL-PHP.md that was distributed with this source code.
 */
import { Components } from "../types/api";
/**
 * Describes the results from a {@link getNetworkLevel} function call.
 */
export interface NetworkLevel {
    level: number;
    preciseLevel: number;
    currentExp: number;
    expToLevel: number;
    expToNextLevel: number;
    remainingExpToNextLevel: number;
}
/**
 * Calculates the total EXP required for a specific network level.
 * @param level Level you're getting the EXP required for. Can be a float or an integer.
 * @category Helper
 */
export declare function getExpFromNetworkLevel(level: number): number;
/**
 * Calculates the network level and returns a {@link NetworkLevel} interface.
 * @param data The player object or the raw EXP number.
 * @category Helper
 */
export declare function getNetworkLevel(data: Components.Schemas.Player | number): NetworkLevel;
