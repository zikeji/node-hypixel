/**
 * This portion of code was ported from the [hypixel-php](https://github.com/Plancke/hypixel-php) library.
 *
 * Copyright (c) 2021 Zikeji
 * Copyright (c) 2017 Aäron Plancke
 *
 * For the original full copyright and license information, please view the LICENSE-HYPIXEL-PHP.md that was distributed with this source code.
 */
import { MinecraftColorAsHex, MinecraftFormatting } from "./MinecraftFormatting";
/**
 * Describes the properties of a Prestige object returned by {@link getSkyWarsPrestigeForLevel}.
 */
export interface SkyWarsPrestige {
    id: string;
    name: string;
    color: MinecraftFormatting;
    colorHex: MinecraftColorAsHex;
    minimumLevel: number;
    icon: {
        version: number;
        material: string;
        typeId: number;
        data: number;
    };
    textIcon: string | null;
}
/**
 * An array of the prestiges in SkyWars, listed in order of lowest to highest.
 */
export declare const SkyWarsPrestiges: SkyWarsPrestige[];
/**
 * Returns a {@link SkyWarsPrestige} object for the level you supplied.
 * @param level The level of the player you are checking. TODO: obtain
 */
export declare function getSkyWarsPrestigeForLevel(level: number): SkyWarsPrestige;
