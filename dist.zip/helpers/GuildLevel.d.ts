/**
 * This portion of code was ported from the [hypixel-php](https://github.com/Plancke/hypixel-php) library.
 *
 * Copyright (c) 2020 Zikeji
 * Copyright (c) 2017 Aäron Plancke
 *
 * For the original full copyright and license information, please view the LICENSE-HYPIXEL-PHP.md that was distributed with this source code.
 */
import { Components } from "../types/api";
/**
 * Describes the results of the {@link getGuildLevel} output object.
 */
export interface GuildLevel {
    level: number;
    preciseLevel: number;
    currentExp: number;
    expToLevel: number;
    expToNextLevel: number;
    remainingExpToNextLevel: number;
}
/**
 * Calculates the guild level and returns a {@link GuildLevel} interface.
 * @param data The guild object or the raw EXP number.
 * @category Helper
 */
export declare function getGuildLevel(data: Components.Schemas.Guild | number): GuildLevel;
