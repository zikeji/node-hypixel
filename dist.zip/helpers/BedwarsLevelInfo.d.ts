/**
 * This portion of code was ported from the [hypixel-php](https://github.com/Plancke/hypixel-php) library.
 *
 * Copyright (c) 2020 Zikeji
 * Copyright (c) 2017 Aäron Plancke
 *
 * For the original full copyright and license information, please view the LICENSE-HYPIXEL-PHP.md that was distributed with this source code.
 */
import { Components } from "../types/api";
/**
 * Describes the results of the {@link getBedwarsLevelInfo} helper.
 */
export interface BedwarsLevelInfo {
    level: number;
    prestige: number;
    prestigeName: string;
    prestigeColor: string;
    prestigeColorHex: string;
    levelInCurrentPrestige: number;
}
/**
 * Calculates the BedWars prestige and level of a player and returns a {@link BedwarsLevelInfo} interface.
 * @category Helper
 */
export declare function getBedwarsLevelInfo(data: Components.Schemas.Player | number): BedwarsLevelInfo;
