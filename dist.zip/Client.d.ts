import { FindGuild } from "./methods/findGuild";
import { Friends } from "./methods/friends";
import { Guild } from "./methods/guild";
import { Player } from "./methods/player";
import { RecentGames } from "./methods/recentGames";
import { Resources } from "./methods/resources";
import { SkyBlock } from "./methods/skyblock";
import { Status } from "./methods/status";
import type { Components, Paths } from "./types/api";
import { ResultObject } from "./util/ResultObject";
/** @hidden */
export interface RateLimitData {
    /**
     * Remaining API calls until the limit resets.
     */
    remaining: number;
    /**
     * Time, in seconds, until remaining resets to limit.
     */
    reset: number;
    /**
     * How many requests per minute your API key can make.
     */
    limit: number;
}
/**
 * Possible meta options returned on the meta variable.
 */
export interface DefaultMeta {
    /**
     * If this request required an API key it returned rate limit information in the headers, which is included here.
     */
    ratelimit?: RateLimitData;
    /**
     * If you included a cache get/set method in the options, this value will be set to true if that cache was hit.
     */
    cached?: boolean;
    /**
     * Data from CloudFlare's headers in regards to caching - particularly relevant for resources endpoints.
     */
    cloudflareCache?: {
        /**
         * Cloudflare cache status.
         */
        status: "HIT" | "MISS" | "BYPASS" | "EXPIRED" | "DYNAMIC";
        /**
         * Cloudflare cache age.
         */
        age?: number;
        /**
         * Cloudflare max cache age.
         */
        maxAge?: number;
    };
}
/** @hidden */
export interface RequestOptions {
    url: string;
    timeout: number;
    userAgent: string;
    noRateLimit: boolean;
    getRateLimitHeaders: Client["getRateLimitHeaders"];
}
/** @hidden */
export interface Parameters {
    [parameter: string]: string;
}
/**
 * If you want built in caching, implementing these methods (or utilitizing an library that includes these methods) is a must. Refer to the [cache](https://node-hypixel.zikeji.com/guide/cache) guide.
 */
export interface BasicCache {
    get<T extends Components.Schemas.ApiSuccess>(key: string): Promise<(T & DefaultMeta) | undefined>;
    set<T extends Components.Schemas.ApiSuccess>(key: string, value: T & DefaultMeta): Promise<void>;
}
export interface ClientOptions {
    /**
     * Amount of times to retry a failed request.
     * @default 3
     */
    retries?: number;
    /**
     * The time, in milliseconds, you want to wait before giving up on the method call.
     *
     * **NOTE:** This option is ignored when being [used in Deno](https://github.com/denoland/deno/issues/7019).
     * @default 10000
     */
    timeout?: number;
    /**
     * User agent the client uses when making calls to Hypixel's API
     * @default @zikeji/hypixel
     */
    userAgent?: string;
    /**
     * Functions you want to use for caching results. Optional.
     */
    cache?: BasicCache;
}
export declare interface Client {
    /**
     * Listen to the "limited" event which emits when the client starts limiting your calls due to hitting the rate limit.
     * @category Events
     */
    on(event: "limited", listener: (limit: number, reset: Date) => void): this;
    /**
     * Listen to the "reset" event which emits when the API rate limit resets.
     * @category Events
     */
    on(event: "reset", listener: () => void): this;
    /**
     * Listen once to the "limited" event which emits when the client starts limiting your calls due to hitting the rate limit.
     * @category Events
     */
    once(event: "limited", listener: (limit: number, reset: Date) => void): this;
    /**
     * Listen once to the "reset" event which emits when the API rate limit resets.
     * @category Events
     */
    once(event: "reset", listener: () => void): this;
    /**
     * Remove your function listening to the "limited" event.
     * @category Events
     */
    off(event: "limited", listener: () => void): this;
    /**
     * Remove your function listening to the "reset" event.
     * @category Events
     */
    off(event: "reset", listener: () => void): this;
}
export declare class Client {
    /**
     * Create a new instance of the API client.
     * @param key Your Hypixel API key.
     * @param options Any options and customizations being applied.
     */
    constructor(key: string, options?: ClientOptions);
    /**
     * Returns list of boosters.
     * @example
     * ```typescript
     * const boosters = await client.boosters();
     * console.log(boosters);
     * ```
     * @category API
     */
    boosters(): Promise<ResultObject<Paths.Boosters.Get.Responses.$200, ["success"]>>;
    /**
     * Returns the id of the requested guild if found.
     * @example
     * ```typescript
     * const { guild } = await client.findGuild.byUuid("20934ef9488c465180a78f861586b4cf");
     * console.log(guild);
     * // 553490650cf26f12ae5bac8f
     * ```
     * @category API
     */
    findGuild: FindGuild;
    /**
     * Returns friendships for given player.
     * @example
     * ```typescript
     * const friends = await client.friends.uuid("20934ef9488c465180a78f861586b4cf");
     * console.log(friends);
     * ```
     * @category API
     */
    friends: Friends;
    /**
     * Returns the current player count along with the player count of each public game + mode on the server.
     * @example
     * ```typescript
     * const response = await client.gameCounts();
     * console.log(response);
     * ```
     * @category API
     */
    gameCounts(): Promise<ResultObject<Paths.GameCounts.Get.Responses.$200, ["success"]>>;
    /**
     * Returns the guild by the requested ID if found.
     * @example
     * ```typescript
     * const guild = await client.guild.id("553490650cf26f12ae5bac8f");
     * ```
     * @category API
     */
    guild: Guild;
    /**
     * Returns information regarding given key.
     * @example
     * ```typescript
     * const key = await client.key();
     * console.log(key);
     * ```
     * @category API
     */
    key(): Promise<ResultObject<Paths.Key.Get.Responses.$200, ["record"]>>;
    /**
     * Returns a list of the official leaderboards and their current standings for games on the network.
     * @example
     * ```typescript
     * const leaderboards = await client.leaderboards();
     * console.log(leaderboards);
     * ```
     * @category API
     */
    leaderboards(): Promise<ResultObject<Paths.Leaderboards.Get.Responses.$200, ["leaderboards"]>>;
    /**
     * Returns a player's data, such as game stats.
     * @example
     * ```typescript
     * const player = await client.player.uuid("20934ef9488c465180a78f861586b4cf");
     * console.log(player);
     * ```
     * @category API
     */
    player: Player;
    /**
     * Returns current player count.
     * @example
     * ```typescript
     * const response = await client.playerCounts();
     * console.log(response);
     * ```
     * @category API
     */
    playerCount(): Promise<ResultObject<Paths.PlayerCount.Get.Responses.$200, ["success"]>>;
    /**
     * Returns recent games of a player. A maximum of 100 games are returned and recent games are only stored for up to 3 days at this time.
     * @example
     * ```typescript
     * const response = await client.recentGames.uuid("20934ef9488c465180a78f861586b4cf");
     * console.log(response);
     * ```
     * @category API
     */
    recentGames: RecentGames;
    /**
     * Relatively static Hypixel resources that don't change often at all.
     * @category API
     */
    resources: Resources;
    /**
     * All SkyBlock related endpoints.
     * @category API
     */
    skyblock: SkyBlock;
    /**
     * Returns online status information for given player, including game, mode and map when available.
     * @example
     * ```typescript
     * const response = await client.status.uuid("20934ef9488c465180a78f861586b4cf");
     * console.log(response);
     * ```
     * @category API
     */
    status: Status;
    /**
     * Returns some statistics about Watchdog & bans.
     * @example
     * ```typescript
     * const response = await client.watchdogstats();
     * console.log(response);
     * // {
     * //   watchdog_lastMinute: 1,
     * //   staff_rollingDaily: 3014,
     * //   watchdog_total: 5589923,
     * //   watchdog_rollingDaily: 4662,
     * //   staff_total: 1874174
     * // }
     * ```
     * @category API
     */
    watchdogstats(): Promise<ResultObject<Paths.Watchdogstats.Get.Responses.$200, ["success"]>>;
    /**
     * The raw query method used by this library. You may use this if you need to use an undocumented method with this library.
     *
     * @category Custom
     * @param path The path on the method you want to query.
     * @param parameters Any search parameters you want to use.
     * @typeParam T As all of Hypixel's API methods return a basic `{ success: boolean; cause?: string; }`, this type parameter (if using Typescript) extends an interface including those.
     * @example
     * Getting the ID of a guild using the [findGuild](https://github.com/HypixelDev/PublicAPI/blob/master/Documentation/methods/findGuild.md) method.
     * ```javascript
     * const response = await client.call("findGuild", { byName: "Mini Squid" });
     * console.log(response);
     * // { success: true, guild: '553490650cf26f12ae5bac8f' }
     * ```
     */
    call<T extends Components.Schemas.ApiSuccess>(path: string, parameters?: Parameters): Promise<T & {
        cached?: boolean;
    }>;
}
export default Client;
