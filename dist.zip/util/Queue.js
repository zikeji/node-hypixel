"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Queue = void 0;
/** @internal */
class Queue {
    constructor() {
        this.promises = [];
    }
    /**
     * Wait for the queue.
     */
    wait() {
        const next = this.next();
        this.queuePromise();
        return next;
    }
    /**
     * Get the next in queue.
     */
    next() {
        if (this.promises.length > 0) {
            return this.promises[this.promises.length - 1][0];
        }
        return Promise.resolve();
    }
    /**
     * Free up the next in queue.
     */
    free() {
        const queued = this.promises.shift();
        if (typeof queued !== "undefined") {
            queued[1]();
        }
    }
    /**
     * Create an empty promise and add it to the queue.
     */
    queuePromise() {
        let resolve;
        const promise = new Promise((res) => {
            resolve = res;
        });
        this.promises.push([promise, () => resolve()]);
    }
}
exports.Queue = Queue;
//# sourceMappingURL=Queue.js.map