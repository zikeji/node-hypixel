"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getResultObject = void 0;
/** @hidden */
function getResultObject(response, keys) {
    const clonedResponse = JSON.parse(JSON.stringify(response));
    if (!keys.every((key) => key in clonedResponse)) {
        throw new TypeError(`One or more key in "${keys.join('"," ')}" was not in the response.`);
    }
    const obj = {};
    const { ratelimit, cached, cloudflareCache } = clonedResponse;
    const meta = {};
    if (cached) {
        meta.cached = true;
        delete clonedResponse.cached;
    }
    if (cloudflareCache) {
        meta.cloudflareCache = cloudflareCache;
        delete clonedResponse.cloudflareCache;
    }
    if (ratelimit) {
        if (!cached &&
            (!meta.cloudflareCache || meta.cloudflareCache.status !== "HIT")) {
            meta.ratelimit = ratelimit;
        }
        delete clonedResponse.ratelimit;
    }
    let assignedMeta = false;
    keys.forEach((key) => {
        const value = clonedResponse[key];
        if (typeof value === "string" ||
            typeof value === "number" ||
            typeof value === "boolean") {
            delete clonedResponse[key];
            assignedMeta = true;
            meta[key] = value;
        }
    });
    if (assignedMeta) {
        // we want the remainder merged into the object.
        Object.assign(obj, clonedResponse);
        Object.defineProperty(obj, "meta", {
            enumerable: false,
            value: meta,
        });
        return obj;
    }
    // we want all the keys merged with the root and the remainder assigned to meta.
    keys.forEach((key) => {
        Object.assign(obj, clonedResponse[key]);
        delete clonedResponse[key];
    });
    Object.assign(meta, clonedResponse);
    Object.defineProperty(obj, "meta", {
        enumerable: false,
        value: meta,
    });
    return obj;
}
exports.getResultObject = getResultObject;
//# sourceMappingURL=ResultObject.js.map