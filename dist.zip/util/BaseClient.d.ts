import { Components } from "../types/api";
export declare abstract class BaseClient {
    abstract call<T extends Components.Schemas.ApiSuccess>(path: string, parameters?: Record<string, string>): Promise<T & {
        cached?: boolean;
    }>;
}
