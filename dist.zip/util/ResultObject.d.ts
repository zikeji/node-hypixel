import { DefaultMeta } from "../types/DefaultMeta";
import { Components } from "../types/api";
/**
 * Generic intersection type for result objects to include metadata as a non-enumerable property.
 * @example
 * ```typescript
 * const result = await client.watchdogstats();
 * console.log(result);
 * // {watchdog_lastMinute: 1, staff_rollingDaily: 2609, watchdog_total: 5591714, watchdog_rollingDaily: 4213, …}
 * console.log(result.meta)
 * // {success: true}
 * ```
 */
export declare type ResultObject<T extends Components.Schemas.ApiSuccess, K extends (keyof T)[]> = (T[K[number]] extends string | number | boolean ? Omit<T, K[number]> : T[K[number]]) & {
    meta: (T[K[number]] extends string | number | boolean ? Pick<T, K[number]> : Omit<T, K[number]>) & DefaultMeta;
};
/** @hidden */
export declare function getResultObject<T extends Components.Schemas.ApiSuccess, K extends (keyof T)[]>(response: T & DefaultMeta, keys: K): ResultObject<T, K>;
