import { DefaultMeta } from "../types/DefaultMeta";
import { Components } from "../types/api";
/**
 * Generic intersection type for result arrays to include metadata as a non-enumerable property.
 * @example
 * ```typescript
 * const result = await client.skyblock.news();
 * console.log(result);
 * // (7) [{…}, {…}, {…}, {…}, {…}, {…}, {…}]
 * console.log(result.meta)
 * // {success: true}
 * ```
 */
export declare type ResultArray<T extends Components.Schemas.ApiSuccess, K extends keyof T> = T[K] & {
    meta: Omit<T, K> & DefaultMeta;
};
/** @hidden */
export declare function getResultArray<T extends Components.Schemas.ApiSuccess, K extends keyof T>(response: T & DefaultMeta, key: K): ResultArray<T, K>;
