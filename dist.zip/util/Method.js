"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Method = void 0;
/** @internal */
class Method {
    /** @internal */
    constructor(client) {
        this.client = client;
    }
}
exports.Method = Method;
//# sourceMappingURL=Method.js.map