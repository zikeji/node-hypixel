/// <reference types="node" />
import type { NBTInventoryItem } from "../helpers/TransformItemData";
export declare function parse(value: number[] | string | Buffer): Promise<NBTInventoryItem[]>;
