"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseClient = void 0;
class BaseClient {
}
exports.BaseClient = BaseClient;
//# sourceMappingURL=BaseClient.js.map