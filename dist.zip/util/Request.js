"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.request = void 0;
const https_1 = require("https");
const GenericHTTPError_1 = require("../errors/GenericHTTPError");
const InvalidKeyError_1 = require("../errors/InvalidKeyError");
const RateLimitError_1 = require("../errors/RateLimitError");
/** @internal */
const CACHE_CONTROL_REGEX = /s-maxage=(\d+)/;
/** @internal */
function request(options) {
    return new Promise((resolve, reject) => {
        const clientRequest = https_1.request(options.url, {
            method: "GET",
            timeout: options.timeout,
            headers: {
                "User-Agent": options.userAgent,
                Accept: "application/json",
            },
        }, (incomingMessage) => {
            let responseBody = "";
            incomingMessage.on("data", (chunk) => {
                responseBody += chunk;
            });
            incomingMessage.on("end", () => {
                if (!options.noRateLimit) {
                    options.getRateLimitHeaders(incomingMessage.headers);
                }
                /* istanbul ignore next */
                if (typeof responseBody !== "string" ||
                    responseBody.trim().length === 0) {
                    return reject(new Error(`No response body received.`));
                }
                let responseObject;
                try {
                    responseObject = JSON.parse(responseBody);
                }
                catch (_) {
                    // noop
                }
                if (incomingMessage.statusCode !== 200) {
                    /* istanbul ignore next */
                    if (incomingMessage.statusCode === 429) {
                        return reject(new RateLimitError_1.RateLimitError(`Hit key throttle.`));
                    }
                    if (incomingMessage.statusCode === 403) {
                        return reject(new InvalidKeyError_1.InvalidKeyError("Invalid API Key"));
                    }
                    /* istanbul ignore else */
                    if (
                    /* istanbul ignore next */ (responseObject === null || responseObject === void 0 ? void 0 : responseObject.cause) &&
                        typeof incomingMessage.statusCode === "number") {
                        return reject(new GenericHTTPError_1.GenericHTTPError(incomingMessage.statusCode, responseObject.cause));
                    }
                    /**
                     * Generic catch all that probably should never be caught.
                     */
                    /* istanbul ignore next */
                    return reject(new Error(`${incomingMessage.statusCode} ${incomingMessage.statusMessage}. Response: ${responseBody}`));
                }
                /* istanbul ignore if */
                if (typeof responseObject === "undefined") {
                    return reject(new Error(`Invalid JSON response received. Response: ${responseBody}`));
                }
                /* istanbul ignore else */
                if (incomingMessage.headers["cf-cache-status"]) {
                    const age = parseInt(incomingMessage.headers.age, 10);
                    const maxAge = CACHE_CONTROL_REGEX.exec(incomingMessage.headers["cache-control"]);
                    responseObject.cloudflareCache = Object.assign(Object.assign(Object.assign({ status: incomingMessage.headers["cf-cache-status"] }, (typeof age === "number" && !Number.isNaN(age) && { age })), (incomingMessage.headers["cf-cache-status"] === "HIT" &&
                        (typeof age !== "number" ||
                            Number.isNaN(age)) && /* istanbul ignore next */ { age: 0 })), (maxAge &&
                        typeof maxAge === "object" &&
                        maxAge.length === 2 &&
                        parseInt(maxAge[1], 10) > 0 && {
                        maxAge: parseInt(maxAge[1], 10),
                    }));
                }
                return resolve(responseObject);
            });
        });
        let abortError;
        /* istanbul ignore next */
        clientRequest.once("abort", () => {
            abortError = abortError !== null && abortError !== void 0 ? abortError : new Error("Client aborted this request.");
            reject(abortError);
        });
        /* istanbul ignore next */
        clientRequest.once("error", (error) => {
            abortError = error;
            clientRequest.abort();
        });
        clientRequest.setTimeout(options.timeout, () => {
            abortError = new Error("Hit configured timeout.");
            clientRequest.abort();
        });
        clientRequest.end();
    });
}
exports.request = request;
//# sourceMappingURL=Request.js.map