export declare class RateLimitError extends Error {
    /**
     * Ignore this for code coverage as reproducing a real rate limit error is difficult.
     */
    constructor(message: string);
}
