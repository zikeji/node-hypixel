"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenericHTTPError = void 0;
class GenericHTTPError extends Error {
    constructor(code, message) {
        super(message);
        this.code = code;
        Object.setPrototypeOf(this, GenericHTTPError.prototype);
    }
}
exports.GenericHTTPError = GenericHTTPError;
//# sourceMappingURL=GenericHTTPError.js.map