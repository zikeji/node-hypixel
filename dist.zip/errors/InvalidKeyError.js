"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvalidKeyError = void 0;
class InvalidKeyError extends Error {
    constructor(message) {
        super(message);
        Object.setPrototypeOf(this, InvalidKeyError.prototype);
    }
}
exports.InvalidKeyError = InvalidKeyError;
//# sourceMappingURL=InvalidKeyError.js.map