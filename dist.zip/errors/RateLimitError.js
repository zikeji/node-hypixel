"use strict";
/* istanbul ignore file */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RateLimitError = void 0;
class RateLimitError extends Error {
    /**
     * Ignore this for code coverage as reproducing a real rate limit error is difficult.
     */
    constructor(message) {
        super(message);
        Object.setPrototypeOf(this, RateLimitError.prototype);
    }
}
exports.RateLimitError = RateLimitError;
//# sourceMappingURL=RateLimitError.js.map