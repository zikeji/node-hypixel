export declare class InvalidKeyError extends Error {
    constructor(message: string);
}
