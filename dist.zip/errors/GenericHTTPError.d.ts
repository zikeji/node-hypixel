export declare class GenericHTTPError extends Error {
    /** The status code of the response */
    code: number;
    constructor(code: number, message: string);
}
