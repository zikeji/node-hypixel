"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GuildsResources = void 0;
const Method_1 = require("../../util/Method");
const ResultObject_1 = require("../../util/ResultObject");
const ResultArray_1 = require("../../util/ResultArray");
class GuildsResources extends Method_1.Method {
    /**
     * Retrieve a list of achievements a Hypixel guild can accomplish.
     * @example
     * ```typescript
     * const achievements = await client.resources.guilds.achievements();
     * ```
     * @category API
     */
    achievements() {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultObject_1.getResultObject(yield this.client.call("resources/guilds/achievements"), ["success", "lastUpdated"]);
        });
    }
    /**
     * Retrieve a list of permissions that a Hypixel guild master can use.
     * @example
     * ```typescript
     * const permissions = await client.resources.guilds.permissions();
     * ```
     * @category API
     */
    permissions() {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultArray_1.getResultArray(yield this.client.call("resources/guilds/permissions"), "permissions");
        });
    }
}
exports.GuildsResources = GuildsResources;
//# sourceMappingURL=guilds.js.map