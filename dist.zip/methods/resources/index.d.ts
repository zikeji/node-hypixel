import { Paths } from "../../types/api";
import { Method } from "../../util/Method";
import { ResultObject } from "../../util/ResultObject";
import { GuildsResources } from "./guilds";
import { SkyBlockResources } from "./skyblock";
export declare class Resources extends Method {
    /**
     * Returns all the achievements for each gamemode on the Hypixel network.
     * @example
     * ```typescript
     * const achievements = await client.resources.achievements();
     * ```
     * @category API
     */
    achievements(): Promise<ResultObject<Paths.ResourcesAchievements.Get.Responses.$200, [
        "achievements"
    ]>>;
    /**
     * Returns all the challenges for each gamemode on the Hypixel network.
     * @example
     * ```typescript
     * const challenges = await client.resources.challenges();
     * ```
     * @category API
     */
    challenges(): Promise<ResultObject<Paths.ResourcesChallenges.Get.Responses.$200, ["challenges"]>>;
    /**
     * Returns all the quests for each gamemode on the Hypixel network.
     * @example
     * ```typescript
     * const quests = await client.resources.quests();
     * ```
     * @category API
     */
    quests(): Promise<ResultObject<Paths.ResourcesQuests.Get.Responses.$200, ["quests"]>>;
    /**
     * Guild related resources.
     * @category API
     */
    guilds: GuildsResources;
    /**
     * SkyBlock related resources.
     * @category API
     */
    skyblock: SkyBlockResources;
}
