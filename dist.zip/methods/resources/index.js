"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Resources = void 0;
const Method_1 = require("../../util/Method");
const ResultObject_1 = require("../../util/ResultObject");
const guilds_1 = require("./guilds");
const skyblock_1 = require("./skyblock");
class Resources extends Method_1.Method {
    constructor() {
        super(...arguments);
        /**
         * Guild related resources.
         * @category API
         */
        this.guilds = new guilds_1.GuildsResources(this.client);
        /**
         * SkyBlock related resources.
         * @category API
         */
        this.skyblock = new skyblock_1.SkyBlockResources(this.client);
    }
    /**
     * Returns all the achievements for each gamemode on the Hypixel network.
     * @example
     * ```typescript
     * const achievements = await client.resources.achievements();
     * ```
     * @category API
     */
    achievements() {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultObject_1.getResultObject(yield this.client.call("resources/achievements"), ["achievements"]);
        });
    }
    /**
     * Returns all the challenges for each gamemode on the Hypixel network.
     * @example
     * ```typescript
     * const challenges = await client.resources.challenges();
     * ```
     * @category API
     */
    challenges() {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultObject_1.getResultObject(yield this.client.call("resources/challenges"), ["challenges"]);
        });
    }
    /**
     * Returns all the quests for each gamemode on the Hypixel network.
     * @example
     * ```typescript
     * const quests = await client.resources.quests();
     * ```
     * @category API
     */
    quests() {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultObject_1.getResultObject(yield this.client.call("resources/quests"), ["quests"]);
        });
    }
}
exports.Resources = Resources;
//# sourceMappingURL=index.js.map