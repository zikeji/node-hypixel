"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RecentGames = void 0;
const Method_1 = require("../util/Method");
const ResultArray_1 = require("../util/ResultArray");
class RecentGames extends Method_1.Method {
    /**
     * Returns recent games of a player. A maximum of 100 games are returned and recent games are only stored for up to 3 days at this time.
     * @example
     * ```typescript
     * const response = await client.recentGames.uuid("20934ef9488c465180a78f861586b4cf");
     * console.log(response);
     * ```
     * @category API
     */
    uuid(uuid) {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultArray_1.getResultArray(yield this.client.call("recentGames", {
                uuid,
            }), "games");
        });
    }
}
exports.RecentGames = RecentGames;
//# sourceMappingURL=recentGames.js.map