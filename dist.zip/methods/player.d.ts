import { Components, Paths } from "../types/api";
import { Method } from "../util/Method";
import { ResultObject } from "../util/ResultObject";
export declare class Player extends Method {
    /**
     * Returns a player's data, such as game stats.
     * @example
     * ```typescript
     * const player = await client.player.uuid("20934ef9488c465180a78f861586b4cf");
     * console.log(player);
     * ```
     * @category API
     */
    uuid(uuid: Components.Parameters.PlayerUuid.Uuid): Promise<ResultObject<Paths.Player.Get.Responses.$200, ["player"]>>;
}
