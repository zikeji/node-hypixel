"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkyBlockAuction = void 0;
const Method_1 = require("../../util/Method");
const ResultArray_1 = require("../../util/ResultArray");
class SkyBlockAuction extends Method_1.Method {
    /**
     * Returns SkyBlock auctions by either player, profile or auction uuid. Only "active" auctions are returned, these are auctions that are still open or that have not had all bids/items claimed.
     * @example
     * ```typescript
     * const auctions = await client.skyblock.auction.player("347ef6c1daac45ed9d1fa02818cf0fb6");
     * ```
     * @category API
     */
    player(player) {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultArray_1.getResultArray(yield this.client.call("skyblock/auction", { player }), "auctions");
        });
    }
    /**
     * Returns SkyBlock auctions by either player, profile or auction uuid. Only "active" auctions are returned, these are auctions that are still open or that have not had all bids/items claimed.
     * @example
     * ```typescript
     * const auctions = await client.skyblock.auction.profile("347ef6c1daac45ed9d1fa02818cf0fb6");
     * ```
     * @category API
     */
    profile(profile) {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultArray_1.getResultArray(yield this.client.call("skyblock/auction", { profile }), "auctions");
        });
    }
    /**
     * Returns SkyBlock auctions by either player, profile or auction uuid. Only "active" auctions are returned, these are auctions that are still open or that have not had all bids/items claimed.
     * @example
     * ```typescript
     * const auctions = await client.skyblock.auction.uuid("409a1e0f261a49849493278d6cd9305a");
     * ```
     * @category API
     */
    uuid(uuid) {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultArray_1.getResultArray(yield this.client.call("skyblock/auction", { uuid }), "auctions");
        });
    }
}
exports.SkyBlockAuction = SkyBlockAuction;
//# sourceMappingURL=auction.js.map