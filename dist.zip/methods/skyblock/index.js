"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkyBlock = void 0;
const Method_1 = require("../../util/Method");
const ResultArray_1 = require("../../util/ResultArray");
const ResultObject_1 = require("../../util/ResultObject");
const auction_1 = require("./auction");
const auctions_1 = require("./auctions");
const profiles_1 = require("./profiles");
class SkyBlock extends Method_1.Method {
    constructor() {
        super(...arguments);
        /**
         * Returns SkyBlock auctions by either player, profile or auction uuid. Only "active" auctions are returned, these are auctions that are still open or that have not had all bids/items claimed.
         * @example
         * ```typescript
         * let auctions = await client.skyblock.auction.player("347ef6c1daac45ed9d1fa02818cf0fb6");
         * auctions = await client.skyblock.auction.profile("347ef6c1daac45ed9d1fa02818cf0fb6");
         * auctions = await client.skyblock.auction.uuid("409a1e0f261a49849493278d6cd9305a");
         * ```
         * @category API
         */
        this.auction = new auction_1.SkyBlockAuction(this.client);
        /**
         * Returns SkyBlock auctions that are currently active in the in-game Auction House.
         * @example
         * ```typescript
         * const { auctions } = await client.skyblock.auctions.page(0);
         * ```
         * @category API
         */
        this.auctions = new auctions_1.SkyBlockAuctions(this.client);
        /**
         * Returns an array SkyBlock profile's data, such as stats, objectives etc. The data returned can differ depending on the players in-game API settings. The request takes a player UUID.
         * @example
         * ```typescript
         * const profiles = await client.skyblock.profiles.uuid("20934ef9488c465180a78f861586b4cf");
         * ```
         * @category API
         */
        this.profiles = new profiles_1.SkyBlockProfiles(this.client);
    }
    /**
     * Returns SkyBlock auctions which ended in the last 60 seconds (More precisely, whatever time is defined in the "Cache-Control" header of the response).
     * @example
     * ```typescript
     * const { auctions } = await client.skyblock.auctions_ended();
     * ```
     * @category API
     */
    auctions_ended() {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultObject_1.getResultObject(yield this.client.call("skyblock/auctions_ended"), ["success"]);
        });
    }
    /**
     * Returns the list of [products](https://github.com/HypixelDev/PublicAPI/blob/master/Documentation/methods/skyblock/bazaar.md#product-description) along with their sell summary, buy summary and quick status.
     * @example
     * ```typescript
     * const products = await client.skyblock.bazaar();
     * ```
     * @category API
     */
    bazaar() {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultObject_1.getResultObject(yield this.client.call("skyblock/bazaar"), ["products"]);
        });
    }
    /**
     * Returns SkyBlock news, including a title, description and a thread.
     * @example
     * ```typescript
     * const news = await client.skyblock.news();
     * ```
     * @category API
     */
    news() {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultArray_1.getResultArray(yield this.client.call("skyblock/news"), "items");
        });
    }
    /**
     * Returns a SkyBlock profile's data, such as stats, objectives etc. The data returned can differ depending on the players in-game API settings.
     * @example
     * ```typescript
     * const news = await client.skyblock.profile("20934ef9488c465180a78f861586b4cf");
     * ```
     * @category API
     */
    profile(profile) {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultObject_1.getResultObject(yield this.client.call("skyblock/profile", { profile }), ["profile"]);
        });
    }
}
exports.SkyBlock = SkyBlock;
//# sourceMappingURL=index.js.map