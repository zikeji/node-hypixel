import { Paths } from "../../types/api";
import { Method } from "../../util/Method";
import { ResultObject } from "../../util/ResultObject";
export declare class SkyBlockAuctions extends Method {
    /**
     * Returns SkyBlock auctions that are currently active in the in-game Auction House.
     * @example
     * ```typescript
     * const { auctions } = await client.skyblock.auctions.page(0);
     * ```
     * @category API
     */
    page(page?: Paths.SkyblockAuctions.Get.Parameters.Page): Promise<ResultObject<Paths.SkyblockAuctions.Get.Responses.$200, ["success"]>>;
}
