"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkyBlockProfiles = void 0;
const Method_1 = require("../../util/Method");
const ResultArray_1 = require("../../util/ResultArray");
class SkyBlockProfiles extends Method_1.Method {
    /**
     * Returns an array SkyBlock profile's data, such as stats, objectives etc. The data returned can differ depending on the players in-game API settings. The request takes a player UUID.
     * @example
     * ```typescript
     * const profiles = await client.skyblock.profiles.uuid("20934ef9488c465180a78f861586b4cf");
     * ```
     * @category API
     */
    uuid(uuid) {
        return __awaiter(this, void 0, void 0, function* () {
            return ResultArray_1.getResultArray(yield this.client.call("skyblock/profiles", { uuid }), "profiles");
        });
    }
}
exports.SkyBlockProfiles = SkyBlockProfiles;
//# sourceMappingURL=profiles.js.map