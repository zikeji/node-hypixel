import { Paths } from "../../types/api";
import { Method } from "../../util/Method";
import { ResultArray } from "../../util/ResultArray";
import { ResultObject } from "../../util/ResultObject";
import { SkyBlockAuction } from "./auction";
import { SkyBlockAuctions } from "./auctions";
import { SkyBlockProfiles } from "./profiles";
export declare class SkyBlock extends Method {
    /**
     * Returns SkyBlock auctions by either player, profile or auction uuid. Only "active" auctions are returned, these are auctions that are still open or that have not had all bids/items claimed.
     * @example
     * ```typescript
     * let auctions = await client.skyblock.auction.player("347ef6c1daac45ed9d1fa02818cf0fb6");
     * auctions = await client.skyblock.auction.profile("347ef6c1daac45ed9d1fa02818cf0fb6");
     * auctions = await client.skyblock.auction.uuid("409a1e0f261a49849493278d6cd9305a");
     * ```
     * @category API
     */
    auction: SkyBlockAuction;
    /**
     * Returns SkyBlock auctions that are currently active in the in-game Auction House.
     * @example
     * ```typescript
     * const { auctions } = await client.skyblock.auctions.page(0);
     * ```
     * @category API
     */
    auctions: SkyBlockAuctions;
    /**
     * Returns SkyBlock auctions which ended in the last 60 seconds (More precisely, whatever time is defined in the "Cache-Control" header of the response).
     * @example
     * ```typescript
     * const { auctions } = await client.skyblock.auctions_ended();
     * ```
     * @category API
     */
    auctions_ended(): Promise<ResultObject<Paths.SkyblockAuctionsEnded.Get.Responses.$200, ["success"]>>;
    /**
     * Returns the list of [products](https://github.com/HypixelDev/PublicAPI/blob/master/Documentation/methods/skyblock/bazaar.md#product-description) along with their sell summary, buy summary and quick status.
     * @example
     * ```typescript
     * const products = await client.skyblock.bazaar();
     * ```
     * @category API
     */
    bazaar(): Promise<ResultObject<Paths.SkyblockBazaar.Get.Responses.$200, ["products"]>>;
    /**
     * Returns SkyBlock news, including a title, description and a thread.
     * @example
     * ```typescript
     * const news = await client.skyblock.news();
     * ```
     * @category API
     */
    news(): Promise<ResultArray<Paths.SkyblockNews.Get.Responses.$200, "items">>;
    /**
     * Returns a SkyBlock profile's data, such as stats, objectives etc. The data returned can differ depending on the players in-game API settings.
     * @example
     * ```typescript
     * const news = await client.skyblock.profile("20934ef9488c465180a78f861586b4cf");
     * ```
     * @category API
     */
    profile(profile: Paths.SkyblockProfile.Get.Parameters.Profile): Promise<ResultObject<Paths.SkyblockProfile.Get.Responses.$200, ["profile"]>>;
    /**
     * Returns an array SkyBlock profile's data, such as stats, objectives etc. The data returned can differ depending on the players in-game API settings. The request takes a player UUID.
     * @example
     * ```typescript
     * const profiles = await client.skyblock.profiles.uuid("20934ef9488c465180a78f861586b4cf");
     * ```
     * @category API
     */
    profiles: SkyBlockProfiles;
}
