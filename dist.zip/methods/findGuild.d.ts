import { Components, Paths } from "../types/api";
import { Method } from "../util/Method";
import { ResultObject } from "../util/ResultObject";
export declare class FindGuild extends Method {
    /**
     * Returns the id of the requested guild if found.
     * @example
     * ```typescript
     * const { guild } = await client.findGuild.byName("Mini Squid");
     * console.log(boosters);
     * // 553490650cf26f12ae5bac8f
     * ```
     * @category API
     */
    byName(name: Components.Parameters.ByGuildName.ByName): Promise<ResultObject<Paths.FindGuild.Get.Responses.$200, ["success"]>>;
    /**
     * Returns the id of the requested guild if found.
     * @example
     * ```typescript
     * const { guild } = await client.findGuild.byUuid("20934ef9488c465180a78f861586b4cf");
     * console.log(guild);
     * // 553490650cf26f12ae5bac8f
     * ```
     * @category API
     */
    byUuid(uuid: Components.Parameters.ByUuid.ByUuid): Promise<ResultObject<Paths.FindGuild.Get.Responses.$200, ["success"]>>;
}
