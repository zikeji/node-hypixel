import { Paths } from "../types/api";
import { Method } from "../util/Method";
import { ResultObject } from "../util/ResultObject";
export declare class Guild extends Method {
    /**
     * Returns the guild by the requested ID if found.
     * @example
     * ```typescript
     * const guild = await client.guild.id("553490650cf26f12ae5bac8f");
     * ```
     * @category API
     */
    id(id: Paths.Guild.Get.Parameters.Id): Promise<ResultObject<Paths.Guild.Get.Responses.$200, ["guild"]>>;
    /**
     * Returns the guild by the requested player's UUID if found.
     * @example
     * ```typescript
     * const guild = await client.guild.player("20934ef9488c465180a78f861586b4cf");
     * ```
     * @category API
     */
    player(player: Paths.Guild.Get.Parameters.Player): Promise<ResultObject<Paths.Guild.Get.Responses.$200, ["guild"]>>;
    /**
     * Returns the guild by the requested guild name if found.
     * @example
     * ```typescript
     * const guild = await client.guild.name("Mini Squid");
     * ```
     * @category API
     */
    name(name: Paths.Guild.Get.Parameters.Name): Promise<ResultObject<Paths.Guild.Get.Responses.$200, ["guild"]>>;
}
